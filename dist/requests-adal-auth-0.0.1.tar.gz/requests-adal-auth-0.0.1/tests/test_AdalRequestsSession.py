from requests_adal_auth import AdalRequestsSession


def test_AdalRequestsSession():
    instance = AdalRequestsSession()
