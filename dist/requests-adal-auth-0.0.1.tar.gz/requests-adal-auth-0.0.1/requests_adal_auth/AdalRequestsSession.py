class AdalRequestsSession:
    def AdalRequestsSession(self):
        print("Hello world from AdalRequestsSession")
